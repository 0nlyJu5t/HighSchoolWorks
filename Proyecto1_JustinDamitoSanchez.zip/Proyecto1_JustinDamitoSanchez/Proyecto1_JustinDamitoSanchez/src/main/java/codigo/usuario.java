/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;


/**
 *
 * @author Justin David Dámito Sánchez
 */
public class usuario {
    private String nombre;
    private String usuario;
    private String contra;
    private String cedula;
    private String calcDisp;
    private boolean online;
    
    public usuario(){
}
        //creacion del constructor del objeto de usuario
    public usuario(String nombre , String usuario , String contra , String cedula,String calcDisp,boolean online){
        this.nombre = nombre;
        this.usuario = usuario;
        this.contra = contra;
        this.cedula = cedula;
        this.calcDisp = calcDisp;
        this.online = false;
    }
    
        /**
         * metodos get y set
         * metodos get para obtener el valor del objeto
         * metodos set para establecer el valor de los objetos
         * @since 12/10/23
         */
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public String getUsuario(){
        return usuario;
    }
    public void setUsuario(String usuario){
        this.usuario = usuario;
    }
    
    public String getContra(){
        return contra;
    }
    public void setContra(String contra){
        this.contra = contra;
    }
    
    public String getCedula(){
        return cedula;
    }
    public void setCedula(String cedula){
        this.cedula = cedula;
    }
    
    public String getCalcDisp(){
        return calcDisp;
    }
    public void setCalcDisp(String calcDisp){
        this.calcDisp = calcDisp;
    }
    public boolean getOnline(){
        return online;
    }
    public void setOnline(boolean online){
        this.online = online;
    }

}

