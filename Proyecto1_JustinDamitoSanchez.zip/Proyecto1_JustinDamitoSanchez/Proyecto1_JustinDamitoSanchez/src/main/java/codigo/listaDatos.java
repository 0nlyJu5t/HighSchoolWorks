/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Justin David Dámito Sánchez
 * @since 12/10/23
 * 
 */
public class listaDatos {
    public static ArrayList<String> datos= new ArrayList<>(Arrays.asList("xxxx - xxxx - xxxx"));
            
    /**
     * 
     * @param tipo el tipo de operacion 
     * @param valor los valores que fueron utilizados para la operacion
     * @param result el resultado de la operacion
     */
    public static void setDatos(String tipo,String valor,String result) {
        datos.add(tipo);
        datos.add(valor);
        datos.add(result);
        
    }
}
