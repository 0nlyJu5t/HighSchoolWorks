/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

/**
 *
 * @author Justin David Dámito Sánchez
 */
public class metodosGeometricos {
    
        /**
         * 
         * @param altura
         * @param baseMa
         * @param baseMe
         * @return operacion de altura multiplicado por base mayor por base menor dividido por 2
         * @since 12/10/23
         */
    public double areaRomboide(double altura, double baseMa, double baseMe){
        return (altura*(baseMa * baseMe))/2;
    }
    
        /**
         * 
         * @param diagonalMa
         * @param diagonalMe
         * @return operacion de diagonal mayor por diagonal menor dividido por 2
         * @since 12/10/23
         */
    public static double areaRombo(double diagonalMa, double diagonalMe){
        return (diagonalMa * diagonalMe)/2;
    }
    
        /**
         * 
         * @param perimetro
         * @param apotema
         * @return operacion de periemtro por apotema dividido por 2
         * @since 12/10/23
         */
    public static double areaPoligono(double perimetro, double apotema){
        return (perimetro * apotema)/2;
    }
            
    
    
}
