/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;


import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import javax.swing.JFileChooser;

/**
 *
 * @author Justin David Dámito Sánchez
 * @since 12/10/23
 * 
 */
public class PDF {
    public static void PpfCreation(){
                
        //instancia del array list donde se accede a los datos guardados
        ArrayList<String> datos = listaDatos.datos;
        
        //proceso para crear una manera de seleccionar el lugar de guardado
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecciona la ubicación de guardado");
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            System.out.println("Ubicación de guardado: " + fileToSave.getAbsolutePath());

        
        
        //instancia para la creacion del docuemnto pdf
        Document document = new Document(){};
        try {
            PdfWriter.getInstance(document, new FileOutputStream(fileToSave.getAbsolutePath()+".pdf"));

            document.open();
            Paragraph title = new Paragraph("Título del PDF");
            title.setAlignment(Paragraph.ALIGN_JUSTIFIED);
            document.add(title);
            for(int i = 1;i < datos.size();i+=3){
                document.add(new Paragraph("----------------------"));
                document.add(new Paragraph("\nTipo de operacion: "));
                document.add(new Paragraph(datos.get(i)));
                document.add(new Paragraph("\nDatos utilizados: "));
                document.add(new Paragraph(datos.get(i+1)));
                document.add(new Paragraph("\nResultado: "));
                document.add(new Paragraph(datos.get(i+2)));
            }
            document.close();
            System.out.println("PDF creado correctamente.");
        } catch (DocumentException | FileNotFoundException e) {
            e.printStackTrace();}
        }
    }
}

