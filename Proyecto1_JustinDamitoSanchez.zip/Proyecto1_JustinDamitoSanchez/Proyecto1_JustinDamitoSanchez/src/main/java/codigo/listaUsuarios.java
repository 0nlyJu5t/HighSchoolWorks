/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Justin David Dámito Sánchez
 * @since 12/10/23
 */      
public class listaUsuarios {
    
        //creacion del arrayList donde se almacenaran los usuarios
    public static ArrayList<usuario> lista = new ArrayList<>(Arrays.asList(
        new usuario("Geisel", "G3IS3L", "123456", "987654321", "2",false),
        new usuario("Justin", "justDamn", "123456", "119650179", "1",false),
        new usuario("XXX", "usuario", "123456", "789012345", "3",false)
    ));
}
