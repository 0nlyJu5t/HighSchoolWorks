/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

/**
 *
 * @author Justin David Dámito Sánchez
 * @since 12/10/23
 */
public class metodosElectricidad {
    
        /**
         * 
         * @param voltaje
         * @param corriente
         * @return operacion de voltaje multiplicado por corriente
         * @since 12/10/23
         */
    public double potenciaElectrica(double voltaje,double corriente){
        return voltaje * corriente;
    }
    
        /**
         * 
         * @param intensidad
         * @param resistencia
         * @return operacion de intensidad multiplicado por resistencia
         * @since 12/10/23
         */
    public double voltaje(double intensidad,double resistencia){
        return intensidad * resistencia;
    }
    
        /**
         * 
         * @param voltaje
         * @param intensidad
         * @return operacion de voltaje dividido por intensidad
         * @since 12/10/23
         */
    public double resistencia(double voltaje,double intensidad){
        return voltaje / intensidad;
    }
    
        /**
         * 
         * @param voltaje
         * @param resistencia
         * @return operacion de voltaje dividido por resistencia
         * @since 12/10/23
         */
    public double corriente(double voltaje,double resistencia){
        return voltaje / resistencia;
    }
            
    
}
