/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import codigo.listaDatos;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JFileChooser;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Justin David Dámito Sánchez
 * @since 12/10/23
 * 
 */
public class Excel {
    public static void ExcelCreation(){
        
        //instancia del array list donde se accede a los datos guardados
        ArrayList<String> datos = listaDatos.datos;
        
        //proceso para crear una manera de seleccionar el lugar de guardado
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecciona la ubicación de guardado");
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            System.out.println("Ubicación de guardado: " + fileToSave.getAbsolutePath());

        
        
            //Creacion del  archivo de excel
            //Instancia de la area de trabajo
        XSSFWorkbook workbook = new XSSFWorkbook(); 
         
            //instancia de la hoja e calculo
        XSSFSheet sheet = workbook.createSheet("operaciones");

            //Colocacion de datos dentro de la hoja de calculo
        Map<Integer, Object[]> data = new TreeMap<>();
        data.put(1, new Object[]{"Tipo de operacion", "Datos usados", "Resultado"});
        int rowNumber = 2;
        for (int i = 1; i < datos.size(); i+=3) {
            data.put(rowNumber++, new Object[]{datos.get(i),datos.get(i + 1),datos.get(i + 2)});
        }
        Set<Integer> keyset = data.keySet();
        int rownum = 0;
        for (Integer key : keyset){
            Row row = sheet.createRow(rownum++);
            row.setHeightInPoints(40);
            Object [] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr)
            {
               Cell cell = row.createCell(cellnum++);
               if(obj instanceof String)
                    cell.setCellValue((String)obj);
                else if(obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
        }
        
            //Codigo para ajustar el tamaño de las celdas segun contenido
        for (int i = 0; i < data.get(1).length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        
            //Try Catch en caso de un error al momento de lacreacion
        try
        {
            FileOutputStream out = new FileOutputStream(new File(fileToSave.getAbsolutePath() + ".xlsx"));
            workbook.write(out);
            out.close();
            System.out.println("Informe.xlsx written successfully on disk.");
        } 
        catch (Exception e) 
        {
            System.out.println("catch action");
            e.printStackTrace();
        }
    }
}
}
