/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

/**
 *
 * @author Justin David Dámito Sánchez
 */
public class validacion {
    
        /**
         * 
         * @param dato para validar si es valido o no
         * @return si es valido retorna true y si no es valido retorna false
         * @since 12/10/23
         */
    public boolean validacion(String dato) {
        if(dato.isEmpty()){
            return false;
        }else{         
            try {
            Double.parseDouble(dato);
            return true;
        } catch (NumberFormatException excepcion) {
            return false;}
        }

    }
}
            
                


